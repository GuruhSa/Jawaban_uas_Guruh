<?php

return [
    'site_title' => 'UAS',
];
