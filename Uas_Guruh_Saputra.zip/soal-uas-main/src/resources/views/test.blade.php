<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
<div class="countener">
    @if ($data->'dataSatu'){
    <input type="text" {{ action('HomeController', ['id'=>user]) }}>
    }@else if($data->'dataDua'){
        return ('$data->user.dataDua=$dataDua');
    }@else ()
    return ('$data->dataDua.dataTiga');
    @endif
</div>
</body>
</html>
